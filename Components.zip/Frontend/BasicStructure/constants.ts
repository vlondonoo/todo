/*BCP-constants*/
export const BACKEND_URI = 'BACKEND-URL';
/*ECP-constants*/